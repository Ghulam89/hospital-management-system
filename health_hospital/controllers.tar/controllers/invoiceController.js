const { Types } = require("mongoose");
const Invoice = require("../models/invoiceModel");
const moment = require("moment");
const {
  assignBranchIdForCreate,
  mergeBranchScopedQuery,
  branchDocumentVisible,
  applyStrictBranchListFilter,
} = require("../utils/branchScope");

// 1. Create invoice
const addinvoice = async (req, res) => {
  try {



    const body = assignBranchIdForCreate(req, { ...req.body });
    const data = await Invoice.create(body);
    return res.status(200).json({ status: "ok", data: data });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};





// 2. Get all invoices
const getinvoices = async (req, res) => {
  try {
    const {
      doctorId,
      departmentId,
      patientMR,
      patientName,
      patientPhone,
      invoiceNo,
      invoiceNumber,
      paymentMode,
      procedureId,
      startDate,
      endDate,
      status,
      search = '',
      page = 1,
      minTotalBill,
      maxTotalBill,
      minDiscountBill,
      maxDiscountBill,
      minPaid,
      maxPaid,
      minDue,
      maxDue,
      minAdvance,
      maxAdvance,
    } = req.query;

    const requestedLimit = parseInt(req.query.limit, 10);
    const limit = Number.isFinite(requestedLimit) && requestedLimit > 0 ? requestedLimit : 20;
    const query = {};

    const branchStrict = await applyStrictBranchListFilter(req, query);
    if (branchStrict === "empty") {
      const emptySummary = {
        totalSubTotal: 0,
        totalDiscount: 0,
        totalTax: 0,
        grandTotal: 0,
        totalDue: 0,
        totalAdvance: 0,
        totalPaid: 0,
        totalRemaining: 0,
        totalDoctorShare: 0,
        totalHospitalShare: 0,
      };
      return res.status(200).json({
        status: "ok",
        data: [],
        search,
        page,
        summary: emptySummary,
        count: 0,
        totalPages: 0,
        currentPage: parseInt(page, 10) || 1,
        limit,
      });
    }

    // Basic filters
    if (doctorId && doctorId.trim() !== '') {
      // In aggregation pipeline, $match does NOT auto-cast strings to ObjectId.
      // If we keep a string here, it will return zero results even when invoices exist.
      query['doctorId'] = Types.ObjectId.isValid(doctorId) ? new Types.ObjectId(doctorId) : doctorId;
      console.log('Doctor filter applied:', query['doctorId']);
    }
    if (departmentId && departmentId.trim() !== '') {
      // Note: departmentId filter will be handled in aggregation pipeline
      // because department info comes through doctorId
      console.log('Department filter requested:', departmentId);
    }
    // Note: patientMR filter will be handled separately due to nested lookup
    // Handle invoiceNo or invoiceNumber (both map to invoiceNo)
    const invoiceNoValue = invoiceNo || invoiceNumber;
    if (invoiceNoValue && invoiceNoValue.trim() !== '') query['invoiceNo'] = new RegExp(invoiceNoValue, 'i');
    
    // Status filter
    if (status && status.trim() !== '') {
      if (status === 'Paid') {
        query['duePay'] = 0;
      } else if (status === 'Pending') {
        query['duePay'] = { $gt: 0 };
      } else if (status === 'Credit') {
        query['duePay'] = { $lt: 0 };
      }
    }

    // Procedure filter - corrected approach
    if (procedureId && procedureId.trim() !== '') {
      const procVal = Types.ObjectId.isValid(procedureId) ? new Types.ObjectId(procedureId) : procedureId;
      query['item'] = {
        $elemMatch: {
          procedureId: procVal,
        },
      };
    }

    // Payment mode filter - corrected for array
    if (paymentMode && paymentMode.trim() !== '') {
      query['payment.method'] = paymentMode;
      // OR if you need to match any element in the array:
      // query['payment'] = {
      //   $elemMatch: {
      //     method: paymentMode
      //   }
      // };
    }

    // Total bill range
    if (minTotalBill || maxTotalBill) {
      query['totalBill'] = query['totalBill'] || {};
      if (minTotalBill && minTotalBill.trim() !== '') {
        query['totalBill'].$gte = parseFloat(minTotalBill);
        console.log('Min total amount filter applied:', parseFloat(minTotalBill));
      }
      if (maxTotalBill && maxTotalBill.trim() !== '') {
        query['totalBill'].$lte = parseFloat(maxTotalBill);
        console.log('Max total amount filter applied:', parseFloat(maxTotalBill));
      }
    }

    // Discount range
    if (minDiscountBill || maxDiscountBill) {
      query['discountBill'] = query['discountBill'] || {};
      if (minDiscountBill && minDiscountBill.trim() !== '') {
        query['discountBill'].$gte = parseFloat(minDiscountBill);
        console.log('Min discount filter applied:', parseFloat(minDiscountBill));
      }
      if (maxDiscountBill && maxDiscountBill.trim() !== '') {
        query['discountBill'].$lte = parseFloat(maxDiscountBill);
        console.log('Max discount filter applied:', parseFloat(maxDiscountBill));
      }
    }

    // Paid range
    if (minPaid || maxPaid) {
      query['totalPay'] = query['totalPay'] || {};
      if (minPaid && minPaid.trim() !== '') {
        query['totalPay'].$gte = parseFloat(minPaid);
        console.log('Min paid filter applied:', parseFloat(minPaid));
      }
      if (maxPaid && maxPaid.trim() !== '') {
        query['totalPay'].$lte = parseFloat(maxPaid);
        console.log('Max paid filter applied:', parseFloat(maxPaid));
      }
    }

    // Due range
    if (minDue || maxDue) {
      query['duePay'] = query['duePay'] || {};
      if (minDue && minDue.trim() !== '') {
        query['duePay'].$gte = parseFloat(minDue);
        console.log('Min due filter applied:', parseFloat(minDue));
      }
      if (maxDue && maxDue.trim() !== '') {
        query['duePay'].$lte = parseFloat(maxDue);
        console.log('Max due filter applied:', parseFloat(maxDue));
      }
    }

    // Advance range
    if (minAdvance || maxAdvance) {
      query['advancePay'] = query['advancePay'] || {};
      if (minAdvance && minAdvance.trim() !== '') {
        query['advancePay'].$gte = parseFloat(minAdvance);
        console.log('Min advance filter applied:', parseFloat(minAdvance));
      }
      if (maxAdvance && maxAdvance.trim() !== '') {
        query['advancePay'].$lte = parseFloat(maxAdvance);
        console.log('Max advance filter applied:', parseFloat(maxAdvance));
      }
    }

    // Date range filter
    if (startDate || endDate) {
      query['createdAt'] = {};
      if (startDate && startDate.trim() !== '') {
        // Parse incoming ISO string date and use it directly
        const parsedStartDate = new Date(startDate);
        query['createdAt'].$gte = parsedStartDate;
        console.log('Start date filter applied:', parsedStartDate, 'ISO:', parsedStartDate.toISOString());
      }
      if (endDate && endDate.trim() !== '') {
        // Parse incoming ISO string date and use it directly
        const parsedEndDate = new Date(endDate);
        query['createdAt'].$lte = parsedEndDate;
        console.log('End date filter applied:', parsedEndDate, 'ISO:', parsedEndDate.toISOString());
      }
    }

    // Text search
    // Remove $or from query if aggregation is being used
    let useAggregation = false;
    // Use aggregation if patient search filters, department, invoice number, or general search are present
    // OR if date filters are present (to ensure patient filters work correctly with dates)
    if (
      (patientMR && patientMR.trim() !== '') ||
      (patientName && patientName.trim() !== '') ||
      (patientPhone && patientPhone.trim() !== '') ||
      (invoiceNoValue && invoiceNoValue.trim() !== '') ||
      (departmentId && departmentId.trim() !== '') ||
      (search && search.trim() !== '') ||
      (startDate && startDate.trim() !== '') ||
      (endDate && endDate.trim() !== '')
    ) {
      useAggregation = true;
    }
    if (search && search.trim() !== '' && !useAggregation) {
      query['$or'] = [
        { 'patientId.name': { $regex: search, $options: 'i' } },
        { 'patientId.mr': { $regex: search, $options: 'i' } },
        { 'doctorId.name': { $regex: search, $options: 'i' } },
        { 'item.description': { $regex: search, $options: 'i' } },
        { invoiceNo: { $regex: search, $options: 'i' } }
      ];
    }

    let invoices, count;

    // If patientMR filter or departmentId filter is applied, OR search param is present, use aggregation
    if (useAggregation) {
      const pipeline = [
        { $match: query },
        {
          $lookup: {
            from: 'branches',
            localField: 'branchId',
            foreignField: '_id',
            as: 'branchData'
          }
        },
        { $unwind: { path: '$branchData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        { $unwind: { path: '$patientData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'users',
            localField: 'doctorId',
            foreignField: '_id',
            as: 'doctorData'
          }
        },
        { $unwind: { path: '$doctorData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'departments',
            localField: 'doctorData.departmentId',
            foreignField: '_id',
            as: 'departmentData'
          }
        },
        { $unwind: { path: '$departmentData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'procedures',
            localField: 'item.procedureId',
            foreignField: '_id',
            as: 'procedureData'
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'createdById',
            foreignField: '_id',
            as: 'createdByData'
          }
        },
        { $unwind: { path: '$createdByData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'users',
            localField: 'updatedById',
            foreignField: '_id',
            as: 'updatedByData'
          }
        },
        { $unwind: { path: '$updatedByData', preserveNullAndEmptyArrays: true } }
      ];

      // Add conditional filters
      if (patientMR && patientMR.trim() !== '') {
        pipeline.push({
          $match: {
            'patientData.mr': { $regex: patientMR, $options: 'i' }
          }
        });
      }
      if (patientName && patientName.trim() !== '') {
        pipeline.push({
          $match: {
            'patientData.name': { $regex: patientName, $options: 'i' }
          }
        });
      }
      if (patientPhone && patientPhone.trim() !== '') {
        pipeline.push({
          $match: {
            'patientData.phone': { $regex: patientPhone, $options: 'i' }
          }
        });
      }
      if (invoiceNoValue && invoiceNoValue.trim() !== '') {
        pipeline.push({
          $match: {
            'invoiceNo': { $regex: invoiceNoValue, $options: 'i' }
          }
        });
      }
      if (departmentId && departmentId.trim() !== '') {
        pipeline.push({
          $match: {
            'departmentData._id': new Types.ObjectId(departmentId)
          }
        });
      }
      // Add search $match after patientData/doctorData unwind
      if (search && search.trim() !== '') {
        pipeline.push({
          $match: {
            $or: [
              { 'patientData.name': { $regex: search, $options: 'i' } },
              { 'patientData.mr': { $regex: search, $options: 'i' } },
              { 'patientData.phone': { $regex: search, $options: 'i' } },
              { 'patientData.cnic': { $regex: search, $options: 'i' } },
              { 'doctorData.name': { $regex: search, $options: 'i' } },
              { 'item.description': { $regex: search, $options: 'i' } },
              { invoiceNo: { $regex: search, $options: 'i' } }
            ]
          }
        });
      }

      // Add sorting and pagination
      pipeline.push({ $sort: { createdAt: -1 } });
      pipeline.push({ $skip: (parseInt(page) - 1) * limit });
      pipeline.push({ $limit: limit });

      // Count pipeline
      const countPipeline = [
        { $match: query },
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        { $unwind: { path: '$patientData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'users',
            localField: 'doctorId',
            foreignField: '_id',
            as: 'doctorData'
          }
        },
        { $unwind: { path: '$doctorData', preserveNullAndEmptyArrays: true } },
        {
          $lookup: {
            from: 'departments',
            localField: 'doctorData.departmentId',
            foreignField: '_id',
            as: 'departmentData'
          }
        },
        { $unwind: { path: '$departmentData', preserveNullAndEmptyArrays: true } }
      ];

      // Add conditional filters to count pipeline
      if (patientMR && patientMR.trim() !== '') {
        countPipeline.push({
          $match: {
            'patientData.mr': { $regex: patientMR, $options: 'i' }
          }
        });
      }
      if (patientName && patientName.trim() !== '') {
        countPipeline.push({
          $match: {
            'patientData.name': { $regex: patientName, $options: 'i' }
          }
        });
      }
      if (patientPhone && patientPhone.trim() !== '') {
        countPipeline.push({
          $match: {
            'patientData.phone': { $regex: patientPhone, $options: 'i' }
          }
        });
      }
      if (invoiceNoValue && invoiceNoValue.trim() !== '') {
        countPipeline.push({
          $match: {
            'invoiceNo': { $regex: invoiceNoValue, $options: 'i' }
          }
        });
      }
      if (departmentId && departmentId.trim() !== '') {
        countPipeline.push({
          $match: {
            'departmentData._id': new Types.ObjectId(departmentId)
          }
        });
      }

      invoices = await Invoice.aggregate(pipeline);
      const countResult = await Invoice.aggregate(countPipeline);
      count = countResult.length;

      // Debug: print first invoice and patientData
      if (invoices.length > 0) {
        console.log('Aggregation result sample:', invoices[0]);
        console.log('Aggregation patientData:', invoices[0].patientData);
      } else {
        console.log('Aggregation result is empty');
      }

      // Transform data to match expected structure
      invoices = invoices.map(invoice => ({
        ...invoice,
        patientId: invoice.patientData,
        doctorId: invoice.doctorData,
        branchId: invoice.branchData || invoice.branchId,
        item: invoice.item.map(item => ({
          ...item,
          procedureId: invoice.procedureData.find(proc => proc._id.toString() === item.procedureId?.toString())
        }))
      }));

    } else {
      // Use simple find query for other filters
      invoices = await Invoice.find(query)
        .sort({ createdAt: -1 })
        .populate({ path: 'branchId', select: 'name address location phone email' })
        .populate({
          path: 'doctorId',
          populate: {
            path: 'departmentId'
          }
        })
        .populate('patientId')
        .populate('departmentId')
        .populate({
          path: 'item.procedureId',
          model: 'Procedure'
        })
        .limit(limit)
        .skip((parseInt(page) - 1) * limit)
        .exec();

      count = await Invoice.countDocuments(query);
    }

    // Debug log
    console.log('Query:', JSON.stringify(query, null, 2));
    console.log('PatientMR filter:', patientMR);
    console.log('Found invoices:', invoices.length);
    
    // Debug department filter
    if (departmentId && departmentId.trim() !== '') {
      console.log('=== DEPARTMENT FILTER DEBUG ===');
      console.log('DepartmentId filter:', departmentId);
      
      // Check if any invoices have this departmentId
      const directQuery = await Invoice.find({ departmentId: departmentId }).limit(5);
      console.log('Direct departmentId query results:', directQuery.length);
      
      // Check all invoices to see departmentId values
      const allInvoices = await Invoice.find({}).limit(10);
      console.log('Sample invoices departmentId values:');
      allInvoices.forEach((inv, index) => {
        console.log(`Invoice ${index + 1}:`, {
          id: inv._id,
          departmentId: inv.departmentId,
          doctorId: inv.doctorId
        });
      });
      
      // Check if departmentId exists in any invoice
      const hasDepartmentId = await Invoice.findOne({ departmentId: { $exists: true, $ne: null } });
      console.log('Any invoice with departmentId field:', !!hasDepartmentId);
    }
    
    
    const summary = {
  totalSubTotal: 0,
  totalDiscount: 0,
  totalTax: 0,
  grandTotal: 0,
  totalDue: 0,
  totalAdvance: 0,
  totalPaid: 0,
  totalRemaining: 0,
   totalDoctorShare: 0, 
  totalHospitalShare: 0,
};


invoices.forEach(invoice => {
  summary.totalSubTotal += invoice.subTotalBill || 0;
  summary.totalDiscount += invoice.discountBill || 0;
  summary.totalTax += invoice.taxBill || 0;
  summary.grandTotal += invoice.totalBill || 0;
  summary.totalDue += invoice.duePay || 0;
  summary.totalAdvance += invoice.advancePay || 0;
  summary.totalPaid += invoice.totalPay || 0;
  summary.totalRemaining += invoice.remainPay || 0
  
   if (invoice.item && invoice.item.length > 0) {
    invoice.item.forEach(item => {
      summary.totalDoctorShare += item.doctorAmount || 0;
      summary.totalHospitalShare += item.hospitalAmount || 0;
    });
  }
  
});

 


    res.status(200).json({
      status: "ok",
      data: invoices,
      search,
      page,
       summary: summary, 
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
      limit
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};



// 3. Get invoice by id
const getinvoiceById = async (req, res) => {
  try {
    const id = req.params.id;
    const data = await Invoice.findById(id)
      .populate({ path: 'branchId', select: 'name address location phone email' })
      .populate('patientId')
      .populate({ path: 'doctorId', populate: { path: 'departmentId' } })
      .populate('departmentId')
      .populate({ path: 'item.procedureId', model: 'Procedure' });
    if (!data || !(await branchDocumentVisible(req, data.branchId))) {
      return res.status(404).json({ status: "fail", message: "Invoice not found" });
    }
    return res.status(200).json({ status: "ok", data: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. Update invoice
const updateinvoice = async (req, res) => {
  try {
    let id = req.params.id;
    let getImage = await Invoice.findById(id);
    if (!getImage || !(await branchDocumentVisible(req, getImage.branchId))) {
      return res.status(404).json({ status: "fail", message: "Invoice not found" });
    }

    const data = await Invoice.findByIdAndUpdate(
      id,
      { ...req.body },
      { new: true }
    );
    return res.status(200).json({ status: "ok", data: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const addInvoicePayments = async (req, res) => {
  try {
    const id = req.params.id;
    const invoice = await Invoice.findById(id);
    if (!invoice || !(await branchDocumentVisible(req, invoice.branchId))) {
      return res.status(404).json({ status: "error", message: "Invoice not found" });
    }

    const incoming = Array.isArray(req.body?.payments) ? req.body.payments : [];
    const cleanedPayments = incoming
      .map((p) => ({
        method: p?.method || '',
        payDate: p?.payDate ? new Date(p.payDate) : new Date(),
        paid: Number(p?.paid) || 0,
        reference: p?.reference || '',
        chequeNo: p?.chequeNo || '',
        bankName: p?.bankName || '',
        chequeDate: p?.chequeDate ? new Date(p.chequeDate) : undefined,
        notes: p?.notes || '',
      }))
      .filter((p) => p.paid > 0);

    if (cleanedPayments.length === 0) {
      return res.status(400).json({ status: "error", message: "No valid payments provided" });
    }

    invoice.payment = Array.isArray(invoice.payment) ? invoice.payment : [];
    invoice.payment.push(...cleanedPayments);

    const totalPaid = (invoice.payment || []).reduce((sum, p) => sum + (Number(p?.paid) || 0), 0);
    const totalBill = Number(invoice.totalBill) || 0;
    invoice.totalPay = totalPaid;
    invoice.duePay = totalBill - totalPaid;

    const updated = await invoice.save();
    return res.status(200).json({ status: "ok", data: updated });
  } catch (err) {
    console.error("Add invoice payment error:", err);
    res.status(500).json({ error: err.message });
  }
};

// Add invoice refund (records as negative payment)
const addInvoiceRefund = async (req, res) => {
  try {
    const id = req.params.id;
    const invoice = await Invoice.findById(id);
    if (!invoice) {
      return res.status(404).json({ status: "error", message: "Invoice not found" });
    }

    const incoming = Array.isArray(req.body?.refunds) ? req.body.refunds : [];
    const cleanedRefunds = incoming
      .map((p) => ({
        method: p?.method || 'Refund',
        payDate: p?.payDate ? new Date(p.payDate) : new Date(),
        paid: -Math.abs(Number(p?.paid) || 0),
        reference: p?.reference || '',
        chequeNo: p?.chequeNo || '',
        bankName: p?.bankName || '',
        chequeDate: p?.chequeDate ? new Date(p.chequeDate) : undefined,
        notes: p?.notes || '',
      }))
      .filter((p) => Number.isFinite(p.paid) && p.paid < 0);

    if (cleanedRefunds.length === 0) {
      return res.status(400).json({ status: "error", message: "No valid refunds provided" });
    }

    invoice.payment = Array.isArray(invoice.payment) ? invoice.payment : [];
    invoice.payment.push(...cleanedRefunds);

    const totalPaid = (invoice.payment || []).reduce((sum, p) => sum + (Number(p?.paid) || 0), 0);
    const totalBill = Number(invoice.totalBill) || 0;
    invoice.totalPay = totalPaid;
    invoice.duePay = totalBill - totalPaid;

    const updated = await invoice.save();
    return res.status(200).json({ status: "ok", data: updated });
  } catch (err) {
    console.error("Add invoice refund error:", err);
    res.status(500).json({ error: err.message });
  }
};

// Add procedure-level refund: adjusts item amounts and totals, and records negative payment
const addProcedureRefund = async (req, res) => {
  try {
    const id = req.params.id;
    const { procedureId, method, paid, payDate, reference, notes } = req.body || {};
    const refundAmount = Math.abs(Number(paid) || 0);
    if (!procedureId) {
      return res.status(400).json({ status: "error", message: "procedureId is required" });
    }
    if (!refundAmount || !Number.isFinite(refundAmount)) {
      return res.status(400).json({ status: "error", message: "Valid refund amount is required" });
    }

    const invoice = await Invoice.findById(id);
    if (!invoice || !(await branchDocumentVisible(req, invoice.branchId))) {
      return res.status(404).json({ status: "error", message: "Invoice not found" });
    }

    const items = Array.isArray(invoice.item) ? invoice.item : [];
    const normalizeId = (v) => {
      if (!v) return null;
      try {
        return String(v);
      } catch {
        return null;
      }
    };
    const targetId = normalizeId(procedureId);
    let itemIndex = -1;
    for (let i = 0; i < items.length; i++) {
      const pid = normalizeId(items[i]?.procedureId?._id || items[i]?.procedureId);
      if (pid && pid === targetId) {
        itemIndex = i;
        break;
      }
    }
    if (itemIndex < 0) {
      return res.status(404).json({ status: "error", message: "Procedure not found in invoice items" });
    }

    const item = items[itemIndex];
    const currentItemAmount = Number(item?.amount) || 0;

    // Already refunded for this procedure (based on prior payment notes)
    const alreadyRefundedForProcedure = (invoice.payment || [])
      .filter((p) => typeof p?.notes === "string" && p.notes.includes(`ProcedureRefund:${targetId}`))
      .reduce((sum, p) => sum + Math.abs(Number(p?.paid) || 0), 0);

    const maxRefundable = Math.max(0, currentItemAmount - alreadyRefundedForProcedure);
    if (maxRefundable <= 0) {
      return res.status(400).json({ status: "error", message: "Nothing left to refund for this procedure" });
    }
    const applyAmount = Math.min(refundAmount, maxRefundable);

    // Reduce item-level amounts proportionally
    const rate = Number(item?.rate) || 0;
    const quantity = Number(item?.quantity) || 0;
    const itemTotalBefore = Number(item?.total ?? currentItemAmount) || currentItemAmount;
    const proportion = itemTotalBefore > 0 ? applyAmount / itemTotalBefore : 0;

    item.amount = Math.max(0, currentItemAmount - applyAmount);
    if (Number.isFinite(item.doctorAmount)) {
      item.doctorAmount = Math.max(0, Number(item.doctorAmount) - Number(item.doctorAmount) * proportion);
    }
    if (Number.isFinite(item.hospitalAmount)) {
      item.hospitalAmount = Math.max(0, Number(item.hospitalAmount) - Number(item.hospitalAmount) * proportion);
    }
    if (Number.isFinite(item.discount)) {
      item.discount = Math.max(0, Number(item.discount) - Number(item.discount) * proportion);
    }
    if (Number.isFinite(item.tax)) {
      item.tax = Math.max(0, Number(item.tax) - Number(item.tax) * proportion);
    }
    if (Number.isFinite(item.total)) {
      item.total = Math.max(0, Number(item.total) - applyAmount);
    }
    if (rate > 0 && quantity > 0) {
      const qtyReduce = Math.min(quantity, Math.floor(applyAmount / rate));
      if (qtyReduce > 0) {
        item.quantity = quantity - qtyReduce;
      }
    }

    // Recompute invoice totals from items
    const newSubTotal = items.reduce((sum, it) => sum + (Number(it.amount) || 0), 0);
    const newDiscount = items.reduce((sum, it) => sum + (Number(it.discount) || 0), 0);
    const newTax = items.reduce((sum, it) => sum + (Number(it.tax) || 0), 0);
    const newTotal = newSubTotal - newDiscount + newTax;

    invoice.item[itemIndex] = item;
    invoice.subTotalBill = newSubTotal;
    invoice.discountBill = newDiscount;
    invoice.taxBill = newTax;
    invoice.totalBill = newTotal;

    // Record refund as negative payment with a clear note
    const paymentEntry = {
      method: method || "Refund",
      payDate: payDate ? new Date(payDate) : new Date(),
      paid: -Math.abs(applyAmount),
      reference: reference || "",
      chequeNo: "",
      bankName: "",
      chequeDate: undefined,
      notes: `ProcedureRefund:${targetId}${notes ? ` | ${notes}` : ""}`,
    };

    invoice.payment = Array.isArray(invoice.payment) ? invoice.payment : [];
    invoice.payment.push(paymentEntry);

    // Recompute paid/due
    const totalPaid = (invoice.payment || []).reduce((sum, p) => sum + (Number(p?.paid) || 0), 0);
    invoice.totalPay = totalPaid;
    invoice.duePay = (Number(invoice.totalBill) || 0) - totalPaid;

    const updated = await invoice.save();
    return res.status(200).json({
      status: "ok",
      data: updated,
      appliedRefund: applyAmount,
      maxRefundable,
    });
  } catch (err) {
    console.error("Add procedure refund error:", err);
    res.status(500).json({ error: err.message });
  }
};
// 5. Delete invoice
const deleteinvoice = async (req, res) => {
  try {
    const id = req.params.id;
    const row = await Invoice.findById(id);
    if (!row || !(await branchDocumentVisible(req, row.branchId))) {
      return res.status(404).json({ status: "fail", message: "Invoice not found" });
    }
    await Invoice.findByIdAndDelete(id);
    return res
      .status(200)
      .json({ status: "ok", message: "invoice deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get Invoice Summary/Statistics - Separate dedicated API
const getInvoiceSummary = async (req, res) => {
  try {
    const {
      doctorId,
      departmentId,
      patientMR,
      paymentMode,
      procedureId,
      startDate,
      endDate,
      status,
      search = '',
      minTotalBill,
      maxTotalBill,
    } = req.query;

    const matchQuery = {};

    const summaryScopedPatientIds = await getScopedPatientIds(req);
    if (summaryScopedPatientIds !== null) {
      matchQuery.patientId =
        summaryScopedPatientIds.length === 0 ? { $in: [] } : { $in: summaryScopedPatientIds };
    } else {
      const branchInv = await mergeBranchScopedQuery(req);
      if (branchInv) Object.assign(matchQuery, branchInv);
    }

    // Apply same filters as getinvoices
    if (doctorId && doctorId.trim() !== '') {
      matchQuery['doctorId'] = Types.ObjectId.isValid(doctorId) ? new Types.ObjectId(doctorId) : doctorId;
    }
    if (status && status.trim() !== '') {
      if (status === 'Paid') {
        matchQuery['duePay'] = 0;
      } else if (status === 'Pending') {
        matchQuery['duePay'] = { $gt: 0 };
      } else if (status === 'Credit') {
        matchQuery['duePay'] = { $lt: 0 };
      }
    }
    if (procedureId && procedureId.trim() !== '') {
      const procVal = Types.ObjectId.isValid(procedureId)
        ? new Types.ObjectId(procedureId)
        : procedureId;
      matchQuery['item'] = {
        $elemMatch: {
          procedureId: procVal
        }
      };
    }
    if (paymentMode && paymentMode.trim() !== '') {
      matchQuery['payment.method'] = paymentMode;
    }
    if (minTotalBill || maxTotalBill) {
      matchQuery['totalBill'] = {};
      if (minTotalBill && minTotalBill.trim() !== '') {
        matchQuery['totalBill'].$gte = parseFloat(minTotalBill);
      }
      if (maxTotalBill && maxTotalBill.trim() !== '') {
        matchQuery['totalBill'].$lte = parseFloat(maxTotalBill);
      }
    }

    // Date range filter
    if (startDate || endDate) {
      matchQuery['createdAt'] = {};
      if (startDate) {
        matchQuery['createdAt'].$gte = new Date(startDate);
      }
      if (endDate) {
        matchQuery['createdAt'].$lte = new Date(endDate);
      }
    }

    console.log('📊 Calculating invoice summary with filters:', matchQuery);

    // Build aggregation pipeline
    const pipeline = [
      { $match: matchQuery }
    ];

    // If department filter is needed, add lookups
    if (departmentId && departmentId.trim() !== '') {
      pipeline.push(
        {
          $lookup: {
            from: 'users',
            localField: 'doctorId',
            foreignField: '_id',
            as: 'doctorData'
          }
        },
        { $unwind: { path: '$doctorData', preserveNullAndEmptyArrays: true } },
        {
          $match: {
            'doctorData.departmentId': new Types.ObjectId(departmentId)
          }
        }
      );
    }

    if (patientMR && patientMR.trim() !== '') {
      pipeline.push(
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        {
          $match: {
            'patientData.mr': new RegExp(patientMR, 'i')
          }
        }
      );
    }
    if (req.query.patientName && req.query.patientName.trim() !== '') {
      pipeline.push(
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        {
          $match: {
            'patientData.name': new RegExp(req.query.patientName, 'i')
          }
        }
      );
    }
    if (req.query.patientPhone && req.query.patientPhone.trim() !== '') {
      pipeline.push(
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        {
          $match: {
            'patientData.phone': new RegExp(req.query.patientPhone, 'i')
          }
        }
      );
    }

    // Search filter
    if (search && search.trim() !== '') {
      pipeline.push(
        {
          $lookup: {
            from: 'patients',
            localField: 'patientId',
            foreignField: '_id',
            as: 'patientData'
          }
        },
        {
          $match: {
            $or: [
              { invoiceNo: new RegExp(search, 'i') },
              { 'patientData.name': new RegExp(search, 'i') },
              { 'patientData.mr': new RegExp(search, 'i') }
            ]
          }
        }
      );
    }

    // Calculate summary statistics
    pipeline.push({
      $group: {
        _id: null,
        totalTransactions: { $sum: 1 },
        totalRevenue: { $sum: '$totalBill' },
        totalTax: { $sum: '$taxBill' },
        totalDiscount: { $sum: '$discountBill' },
        totalPaid: { $sum: '$totalPay' },
        totalDue: { $sum: '$duePay' },
        subTotal: { $sum: '$subTotalBill' },
        // Doctor and Hospital share calculation
        allItems: { $push: '$item' }
      }
    });

    const result = await Invoice.aggregate(pipeline);

    let summary = {
      totalTransactions: 0,
      totalRevenue: 0,
      totalTax: 0,
      totalDiscount: 0,
      totalPaid: 0,
      totalDue: 0,
      subTotal: 0,
      totalDoctorShare: 0,
      totalHospitalShare: 0
    };

    if (result.length > 0) {
      const stats = result[0];
      
      // Calculate doctor and hospital shares
      let doctorShare = 0;
      let hospitalShare = 0;
      
      if (stats.allItems && Array.isArray(stats.allItems)) {
        stats.allItems.forEach(itemArray => {
          if (Array.isArray(itemArray)) {
            itemArray.forEach(item => {
              doctorShare += item.doctorAmount || 0;
              hospitalShare += item.hospitalAmount || 0;
            });
          }
        });
      }

      summary = {
        totalTransactions: stats.totalTransactions || 0,
        totalRevenue: stats.totalRevenue || 0,
        totalTax: stats.totalTax || 0,
        totalDiscount: stats.totalDiscount || 0,
        totalPaid: stats.totalPaid || 0,
        totalDue: stats.totalDue || 0,
        subTotal: stats.subTotal || 0,
        totalDoctorShare: doctorShare,
        totalHospitalShare: hospitalShare
      };
    }

    console.log('✅ Invoice summary calculated:', summary);

    return res.status(200).json({
      status: "ok",
      summary
    });
  } catch (err) {
    console.error('Error calculating invoice summary:', err);
    res.status(500).json({ 
      status: "error",
      error: err.message 
    });
  }
};

module.exports = {
  addinvoice,
  getinvoices,
  getinvoiceById,
  updateinvoice,
  addInvoicePayments,
  addInvoiceRefund,
  deleteinvoice,
  getInvoiceSummary,
  addProcedureRefund,
};
