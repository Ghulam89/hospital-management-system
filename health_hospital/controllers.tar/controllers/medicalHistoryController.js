const MedicalHistory = require("../models/medicalHistoryModel");
const { applyPatientIdScopeToQuery } = require("../utils/branchScope");

// 1. Create Detail
const addDetail = async (req, res) => {
  try {
      const Detail = await MedicalHistory.create({ ...req.body, });
      return res.status(200).json({ status: "ok", data: Detail });
    
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};





// 2. Get all Details
const getDetails = async (req, res) => {
  try {




    var search = "";
    if (req.query.search) {
      search = req.query.search;
    }

    var page = "1";
    if (req.query.page) {
      page = req.query.page;
    }

    const limit = "20";

    let query={}

    if(req.query.patientId){
      query.patientId=req.query.patientId
    }

    const scopeResult = await applyPatientIdScopeToQuery(req, query);
    if (scopeResult === "empty") {
      return res.status(200).json({
        status: "ok",
        data: [],
        search,
        page,
        count: 0,
        totalPages: 0,
        currentPage: page,
        limit
      });
    }

    const Details = await MedicalHistory.find(query).sort({createdAt:-1})
    .populate(['patientId'])
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const count = await MedicalHistory.find(query)
    .populate(['patientId'])
      .countDocuments();






    return res.status(200).json({
      status: "ok",
      data: Details,
      search,
      page,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      limit
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};




// 3. Get Detail by id
const getDetailById = async (req, res) => {
  try {
    const id = req.params.id;
    const Detail = await MedicalHistory.findById(id);
    return res.status(200).json({ status: "ok", data: Detail });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. Update Detail
const updateDetail = async (req, res) => {
  try {
    let id = req.params.id;
    let getImage = await MedicalHistory.findById(id);

    const updatedDetail = await MedicalHistory.findByIdAndUpdate(
      id,
      { ...req.body },
      { new: true }
    );
    return res.status(200).json({ status: "ok", data: updatedDetail });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 5. Delete Detail
const deleteDetail = async (req, res) => {
  try {
    const id = req.params.id;
    await MedicalHistory.findByIdAndDelete(id);
    return res
      .status(200)
      .json({ status: "ok", message: "Detail deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  addDetail,
  getDetails,
  getDetailById,
  updateDetail,
  deleteDetail,
};
