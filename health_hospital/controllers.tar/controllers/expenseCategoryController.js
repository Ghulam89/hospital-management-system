const ExpenseCategory = require("../models/expenseCategoryModel");
const { mergeBranchScopedQuery, assignBranchIdForCreate, branchDocumentVisible, mergeCatalogPreferenceFilter } = require("../utils/branchScope");

// 1. Create expenseCategory
const addexpenseCategory = async (req, res) => {
  try {



      const data = await ExpenseCategory.create(assignBranchIdForCreate(req, { ...req.body }));
      return res.status(200).json({ status: "ok", data: data });
    
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};



const getexpenseCategorys = async (req, res) => {
  try {
    let search = req.query.search || "";
    let page = parseInt(req.query.page) || 1;
    const limit = req.query.limit ? req.query?.limit : 20;

    const catalogFilter = await mergeCatalogPreferenceFilter(req);
    const filters = [catalogFilter];
    const q = String(search || "").trim();
    if (q) {
      filters.push({ name: { $regex: q, $options: "i" } });
    }
    const baseQuery = filters.length === 1 ? filters[0] : { $and: filters };

    const data = await ExpenseCategory.find(baseQuery).sort({createdAt:-1})
      .limit(limit)
      .skip((page - 1) * limit)
      .exec();

    const count = await ExpenseCategory.countDocuments(baseQuery);

    return res.status(200).json({
      status: "ok",
      data: data,
      search,
      page,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      limit
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 3. Get expenseCategory by id
const getexpenseCategoryById = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ status: "fail", message: "Unauthorized" });
    }
    const id = req.params.id;
    const data = await ExpenseCategory.findById(id);
    if (!data) {
      return res.status(404).json({ status: "fail", message: "Expense category not found" });
    }
    return res.status(200).json({ status: "ok", data: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. Update expenseCategory
const updateexpenseCategory = async (req, res) => {
  try {
    let id = req.params.id;
    let getImage = await ExpenseCategory.findById(id);
    if (!getImage || !(await branchDocumentVisible(req, getImage.branchId))) {
      return res.status(404).json({ status: "fail", message: "Expense category not found" });
    }
    

    const data = await ExpenseCategory.findByIdAndUpdate(
      id,
      { ...req.body,  },
      { new: true }
    );
    return res.status(200).json({ status: "ok", data: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 5. Delete expenseCategory
const deleteexpenseCategory = async (req, res) => {
  try {
    const id = req.params.id;
    const row = await ExpenseCategory.findById(id);
    if (!row || !(await branchDocumentVisible(req, row.branchId))) {
      return res.status(404).json({ status: "fail", message: "Expense category not found" });
    }
    await ExpenseCategory.findByIdAndDelete(id);
    return res
      .status(200)
      .json({ status: "ok", message: "Expense Category deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  addexpenseCategory,
  getexpenseCategorys,
  getexpenseCategoryById,
  updateexpenseCategory,
  deleteexpenseCategory,

};
